﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PROG_RaceDay.Api.Data;
using PROG_RaceDay.Api.Dtos;
using PROG_RaceDay.Api.Models;
using PROG_RaceDay.Api.Services;

namespace PROG_RaceDay.Api.Controllers;

[ApiController, Route("api/auth")]
public class AuthController(AppDbContext db, TokenService tokens) : ControllerBase
{
    [HttpPost("register")]
    public async Task<IActionResult> Register(RegisterDto d)
    {
        if (d.Role is not ("Organiser" or "Participant"))
            return BadRequest(new { message = "Role must be Organiser or Participant." });

        var email = d.Email.Trim().ToLowerInvariant();
        if (await db.Users.AnyAsync(u => u.Email == email))
            return Conflict(new { message = "An account with that email already exists." });

        var user = new User
        {
            FullName = d.FullName.Trim(),
            Email = email,
            PasswordHash = BCrypt.Net.BCrypt.HashPassword(d.Password),
            Role = d.Role
        };
        db.Users.Add(user);
        await db.SaveChangesAsync();
        return Ok(tokens.Build(user));
    }

    [HttpPost("login")]
    public async Task<IActionResult> Login(LoginDto d)
    {
        var email = d.Email.Trim().ToLowerInvariant();
        var user = await db.Users.FirstOrDefaultAsync(u => u.Email == email);
        if (user == null || !BCrypt.Net.BCrypt.Verify(d.Password, user.PasswordHash))
            return Unauthorized(new { message = "Incorrect email or password." });
        return Ok(tokens.Build(user));
    }
}
