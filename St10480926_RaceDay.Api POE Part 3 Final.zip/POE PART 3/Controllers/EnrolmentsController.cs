﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PROG_RaceDay.Api.Data;
using PROG_RaceDay.Api.Dtos;
using PROG_RaceDay.Api.Models;
using PROG_RaceDay.Api.Services;

namespace PROG_RaceDay.Api.Controllers;

[ApiController, Route("api"), Authorize]
public class EnrolmentsController(AppDbContext db) : ControllerBase
{
    private static readonly string[] Statuses = ["Pending", "Confirmed", "Cancelled"];

    [Authorize(Roles = "Participant"), HttpPost("enrolments")]
    public async Task<IActionResult> Enrol(EnrolDto d)
    {
        var uid = User.UserId();
        var ev = await db.Events.FirstOrDefaultAsync(e => e.Id == d.EventId);
        if (ev == null) return NotFound(new { message = "Event not found." });
        if (ev.Date <= DateTime.Now) return BadRequest(new { message = "This event has already taken place." });
        if (!await db.Categories.AnyAsync(c => c.Id == d.CategoryId && c.EventId == d.EventId))
            return BadRequest(new { message = "Please choose a valid category for this event." });

        var existing = await db.Enrolments.FirstOrDefaultAsync(e => e.EventId == d.EventId && e.UserId == uid);
        if (existing != null)
        {
            if (existing.Status != "Cancelled") return Conflict(new { message = "You are already enrolled in this event." });
            existing.Status = "Pending"; existing.CategoryId = d.CategoryId; existing.EnrolledAt = DateTime.Now;
            await db.SaveChangesAsync();
            return Ok(new IdResponse(existing.Id));
        }

        var en = new Enrolment { EventId = d.EventId, CategoryId = d.CategoryId, UserId = uid, Status = "Pending" };
        db.Enrolments.Add(en);
        await db.SaveChangesAsync();
        return Ok(new IdResponse(en.Id));
    }

    [Authorize(Roles = "Participant"), HttpGet("enrolments/mine")]
    public async Task<ActionResult<List<EnrolmentDto>>> Mine()
    {
        var uid = User.UserId();
        return await db.Enrolments.Where(e => e.UserId == uid).OrderBy(e => e.Event.Date)
            .Select(e => new EnrolmentDto(e.Id, e.EventId, e.Event.Name, e.Event.Date, e.Event.Location, e.Event.BannerUrl, e.Category.Name, e.Status, e.EnrolledAt))
            .ToListAsync();
    }

    [Authorize(Roles = "Participant"), HttpPut("enrolments/{id:int}/cancel")]
    public async Task<IActionResult> Cancel(int id)
    {
        var uid = User.UserId();
        var e = await db.Enrolments.FirstOrDefaultAsync(x => x.Id == id && x.UserId == uid);
        if (e == null) return NotFound(new { message = "Enrolment not found." });
        e.Status = "Cancelled";
        await db.SaveChangesAsync();
        return NoContent();
    }

    [Authorize(Roles = "Organiser"), HttpGet("events/{eventId:int}/enrolments")]
    public async Task<ActionResult<List<EventEnrolmentDto>>> ForEvent(int eventId)
    {
        var uid = User.UserId();
        if (!await db.Events.AnyAsync(e => e.Id == eventId && e.OrganiserId == uid)) return NotFound(new { message = "Event not found." });
        return await db.Enrolments.Where(e => e.EventId == eventId).OrderBy(e => e.EnrolledAt)
            .Select(e => new EventEnrolmentDto(e.Id, e.User.FullName, e.User.Email, e.Category.Name, e.Status, e.EnrolledAt))
            .ToListAsync();
    }

    [Authorize(Roles = "Organiser"), HttpPut("enrolments/{id:int}/status")]
    public async Task<IActionResult> SetStatus(int id, StatusDto d)
    {
        if (!Statuses.Contains(d.Status)) return BadRequest(new { message = "Invalid status." });
        var uid = User.UserId();
        var e = await db.Enrolments.Include(x => x.Event).FirstOrDefaultAsync(x => x.Id == id && x.Event.OrganiserId == uid);
        if (e == null) return NotFound(new { message = "Enrolment not found." });
        e.Status = d.Status;
        await db.SaveChangesAsync();
        return NoContent();
    }
}
