﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PROG_RaceDay.Api.Data;
using PROG_RaceDay.Api.Dtos;
using PROG_RaceDay.Api.Models;
using PROG_RaceDay.Api.Services;

namespace PROG_RaceDay.Api.Controllers;

[ApiController, Route("api")]
public class EventsController(AppDbContext db, IBlobService blob) : ControllerBase
{
    // ---------- Public ----------
    [HttpGet("events")]
    public async Task<ActionResult<List<EventSummaryDto>>> List(string? search, string? type, DateTime? from, DateTime? to, decimal? maxDistance)
    {
        var q = db.Events.Where(e => e.Date >= DateTime.Now);
        if (!string.IsNullOrWhiteSpace(search)) q = q.Where(e => e.Name.Contains(search) || e.Location.Contains(search));
        if (!string.IsNullOrWhiteSpace(type)) q = q.Where(e => e.EventType == type);
        if (from.HasValue) q = q.Where(e => e.Date >= from.Value.Date);
        if (to.HasValue) q = q.Where(e => e.Date < to.Value.Date.AddDays(1));
        if (maxDistance.HasValue) q = q.Where(e => e.DistanceKm <= maxDistance.Value);

        return await q.OrderBy(e => e.Date)
            .Select(e => new EventSummaryDto(e.Id, e.Name, e.Description, e.Date, e.Location, e.DistanceKm, e.EventType, e.BannerUrl, e.Organiser.FullName, e.Enrolments.Count(x => x.Status != "Cancelled")))
            .ToListAsync();
    }

    [HttpGet("events/{id:int}")]
    public async Task<ActionResult<EventDetailDto>> Get(int id)
    {
        var e = await db.Events.Include(x => x.Organiser).Include(x => x.Categories).FirstOrDefaultAsync(x => x.Id == id);
        if (e == null) return NotFound(new { message = "Event not found." });
        var count = await db.Enrolments.CountAsync(x => x.EventId == id && x.Status != "Cancelled");
        return new EventDetailDto(e.Id, e.Name, e.Description, e.Date, e.Location, e.DistanceKm, e.EventType, e.BannerUrl,
            e.Organiser.FullName, count, e.Categories.Select(c => new CategoryDto(c.Id, c.Name, c.Description)).ToList());
    }

    // ---------- Organiser ----------
    [Authorize(Roles = "Organiser"), HttpGet("events/mine")]
    public async Task<ActionResult<List<EventSummaryDto>>> Mine()
    {
        var uid = User.UserId();
        return await db.Events.Where(e => e.OrganiserId == uid).OrderByDescending(e => e.Date)
            .Select(e => new EventSummaryDto(e.Id, e.Name, e.Description, e.Date, e.Location, e.DistanceKm, e.EventType, e.BannerUrl, e.Organiser.FullName, e.Enrolments.Count(x => x.Status != "Cancelled")))
            .ToListAsync();
    }

    [Authorize(Roles = "Organiser"), HttpPost("events")]
    public async Task<IActionResult> Create(EventInputDto d)
    {
        if (d.Date <= DateTime.Now) return BadRequest(new { message = "The event date must be in the future." });
        var e = new Event
        {
            OrganiserId = User.UserId(),
            Name = d.Name.Trim(),
            Description = d.Description.Trim(),
            Date = d.Date,
            Location = d.Location.Trim(),
            DistanceKm = d.DistanceKm,
            EventType = d.EventType
        };
        db.Events.Add(e);
        await db.SaveChangesAsync();
        return Ok(new IdResponse(e.Id));
    }

    [Authorize(Roles = "Organiser"), HttpPut("events/{id:int}")]
    public async Task<IActionResult> Update(int id, EventInputDto d)
    {
        var uid = User.UserId();
        var e = await db.Events.FirstOrDefaultAsync(x => x.Id == id && x.OrganiserId == uid);
        if (e == null) return NotFound(new { message = "Event not found." });
        e.Name = d.Name.Trim(); e.Description = d.Description.Trim(); e.Date = d.Date;
        e.Location = d.Location.Trim(); e.DistanceKm = d.DistanceKm; e.EventType = d.EventType;
        await db.SaveChangesAsync();
        return Ok(new IdResponse(e.Id));
    }

    [Authorize(Roles = "Organiser"), HttpDelete("events/{id:int}")]
    public async Task<IActionResult> Delete(int id)
    {
        var uid = User.UserId();
        var e = await db.Events.FirstOrDefaultAsync(x => x.Id == id && x.OrganiserId == uid);
        if (e == null) return NotFound(new { message = "Event not found." });
        db.Events.Remove(e);
        await db.SaveChangesAsync();
        return NoContent();
    }

    [Authorize(Roles = "Organiser"), HttpPost("events/{id:int}/banner")]
    public async Task<IActionResult> UploadBanner(int id, IFormFile file)
    {
        var uid = User.UserId();
        var e = await db.Events.FirstOrDefaultAsync(x => x.Id == id && x.OrganiserId == uid);
        if (e == null) return NotFound(new { message = "Event not found." });
        var err = blob.Validate(file);
        if (err != null) return BadRequest(new { message = err });
        e.BannerUrl = await blob.UploadAsync(file, "banners");
        await db.SaveChangesAsync();
        return Ok(new UrlResponse(e.BannerUrl));
    }

    // ---------- Categories ----------
    [Authorize(Roles = "Organiser"), HttpPost("events/{id:int}/categories")]
    public async Task<IActionResult> AddCategory(int id, CategoryInputDto d)
    {
        var uid = User.UserId();
        if (!await db.Events.AnyAsync(x => x.Id == id && x.OrganiserId == uid)) return NotFound(new { message = "Event not found." });
        var name = d.Name.Trim();
        if (await db.Categories.AnyAsync(c => c.EventId == id && c.Name == name))
            return Conflict(new { message = "This event already has a category with that name." });
        var c = new Category { EventId = id, Name = name, Description = d.Description?.Trim() };
        db.Categories.Add(c);
        await db.SaveChangesAsync();
        return Ok(new IdResponse(c.Id));
    }

    [Authorize(Roles = "Organiser"), HttpDelete("categories/{id:int}")]
    public async Task<IActionResult> DeleteCategory(int id)
    {
        var uid = User.UserId();
        var c = await db.Categories.Include(x => x.Event).FirstOrDefaultAsync(x => x.Id == id && x.Event.OrganiserId == uid);
        if (c == null) return NotFound(new { message = "Category not found." });
        if (await db.Enrolments.AnyAsync(e => e.CategoryId == id))
            return Conflict(new { message = "This category has enrolments and cannot be deleted." });
        db.Categories.Remove(c);
        await db.SaveChangesAsync();
        return NoContent();
    }

    // ---------- Dashboard ----------
    [Authorize(Roles = "Organiser"), HttpGet("organiser/dashboard")]
    public async Task<ActionResult<DashboardDto>> Dashboard()
    {
        var uid = User.UserId();
        var now = DateTime.Now;
        var events = await db.Events.Where(e => e.OrganiserId == uid).OrderBy(e => e.Date)
            .Select(e => new DashboardEventDto(e.Id, e.Name, e.Date, e.Location, e.Enrolments.Count(x => x.Status != "Cancelled"), e.Date >= now))
            .ToListAsync();
        return new DashboardDto(events.Count, events.Sum(x => x.Enrolments), events.Count(x => x.IsUpcoming), events);
    }
}
