﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PROG_RaceDay.Api.Data;
using PROG_RaceDay.Api.Dtos;
using PROG_RaceDay.Api.Services;

namespace PROG_RaceDay.Api.Controllers;

[ApiController, Route("api/profile"), Authorize]
public class ProfileController(AppDbContext db, IBlobService blob) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<ProfileDto>> Get()
    {
        var u = await db.Users.FindAsync(User.UserId());
        if (u == null) return NotFound(new { message = "User not found." });
        return new ProfileDto(u.Id, u.FullName, u.Email, u.Role, u.Phone, u.DateOfBirth, u.ProfilePictureUrl);
    }

    [HttpPut]
    public async Task<IActionResult> Update(ProfileUpdateDto d)
    {
        var u = await db.Users.FindAsync(User.UserId());
        if (u == null) return NotFound(new { message = "User not found." });
        if (d.DateOfBirth.HasValue && d.DateOfBirth.Value > DateTime.Today)
            return BadRequest(new { message = "Date of birth cannot be in the future." });
        u.FullName = d.FullName.Trim(); u.Phone = d.Phone?.Trim(); u.DateOfBirth = d.DateOfBirth;
        await db.SaveChangesAsync();
        return NoContent();
    }

    [HttpPost("picture")]
    public async Task<IActionResult> Picture(IFormFile file)
    {
        var u = await db.Users.FindAsync(User.UserId());
        if (u == null) return NotFound(new { message = "User not found." });
        var err = blob.Validate(file);
        if (err != null) return BadRequest(new { message = err });
        u.ProfilePictureUrl = await blob.UploadAsync(file, "profiles");
        await db.SaveChangesAsync();
        return Ok(new UrlResponse(u.ProfilePictureUrl));
    }
}
