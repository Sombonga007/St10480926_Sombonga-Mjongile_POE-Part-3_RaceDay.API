﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PROG_RaceDay.Api.Data;
using PROG_RaceDay.Api.Dtos;
using PROG_RaceDay.Api.Models;
using PROG_RaceDay.Api.Services;

namespace PROG_RaceDay.Api.Controllers;

[ApiController, Route("api"), Authorize]
public class ResultsController(AppDbContext db) : ControllerBase
{
    [Authorize(Roles = "Organiser"), HttpGet("events/{eventId:int}/results")]
    public async Task<ActionResult<List<ResultRowDto>>> ForEvent(int eventId)
    {
        var uid = User.UserId();
        if (!await db.Events.AnyAsync(e => e.Id == eventId && e.OrganiserId == uid)) return NotFound(new { message = "Event not found." });
        var rows = await db.Enrolments.Where(e => e.EventId == eventId && e.Status == "Confirmed")
            .OrderBy(e => e.User.FullName)
            .Select(e => new { e.Id, e.User.FullName, Category = e.Category.Name, e.Result })
            .ToListAsync();
        return rows.Select(r => new ResultRowDto(r.Id, r.FullName, r.Category, r.Result?.FinishTime.FormatTime(), r.Result?.Position)).ToList();
    }

    [Authorize(Roles = "Organiser"), HttpPost("events/{eventId:int}/results")]
    public async Task<IActionResult> Save(int eventId, List<ResultInputDto> items)
    {
        var uid = User.UserId();
        var ev = await db.Events.FirstOrDefaultAsync(e => e.Id == eventId && e.OrganiserId == uid);
        if (ev == null) return NotFound(new { message = "Event not found." });
        if (ev.Date > DateTime.Now) return BadRequest(new { message = "Results can only be entered after the event has concluded." });
        if (items.Count == 0) return BadRequest(new { message = "No results were submitted." });
        if (items.Select(i => i.Position).Distinct().Count() != items.Count)
            return BadRequest(new { message = "Each finishing position can only be used once." });

        var ids = items.Select(i => i.EnrolmentId).ToList();
        var enrolments = await db.Enrolments.Include(e => e.Result)
            .Where(e => e.EventId == eventId && e.Status == "Confirmed" && ids.Contains(e.Id)).ToListAsync();
        if (enrolments.Count != ids.Count) return BadRequest(new { message = "One or more enrolments are invalid or not confirmed." });

        foreach (var i in items)
        {
            if (!TimeSpan.TryParse(i.FinishTime, out var time) || time <= TimeSpan.Zero)
                return BadRequest(new { message = $"'{i.FinishTime}' is not a valid finish time. Use hh:mm:ss." });
            var en = enrolments.First(e => e.Id == i.EnrolmentId);
            if (en.Result == null) db.Results.Add(new Result { EnrolmentId = en.Id, FinishTime = time, Position = i.Position });
            else { en.Result.FinishTime = time; en.Result.Position = i.Position; }
        }
        await db.SaveChangesAsync();
        return NoContent();
    }

    [Authorize(Roles = "Participant"), HttpGet("results/mine")]
    public async Task<ActionResult<List<MyResultDto>>> Mine()
    {
        var uid = User.UserId();
        var mine = await db.Results.Where(r => r.Enrolment.UserId == uid && r.Enrolment.Event.Date <= DateTime.Now)
            .OrderByDescending(r => r.Enrolment.Event.Date)
            .Select(r => new { r.Enrolment.EventId, EventName = r.Enrolment.Event.Name, r.Enrolment.Event.Date, Category = r.Enrolment.Category.Name, r.FinishTime, r.Position })
            .ToListAsync();
        var eventIds = mine.Select(m => m.EventId).Distinct().ToList();
        var totals = await db.Results.Where(r => eventIds.Contains(r.Enrolment.EventId))
            .GroupBy(r => r.Enrolment.EventId).Select(g => new { EventId = g.Key, Count = g.Count() }).ToDictionaryAsync(x => x.EventId, x => x.Count);
        return mine.Select(m => new MyResultDto(m.EventId, m.EventName, m.Date, m.Category, m.FinishTime.FormatTime(), m.Position, totals[m.EventId])).ToList();
    }
}
