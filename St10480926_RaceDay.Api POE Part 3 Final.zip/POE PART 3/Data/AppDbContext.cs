﻿using Microsoft.EntityFrameworkCore;
using PROG_RaceDay.Api.Models;
using System.Reflection.Emit;

namespace PROG_RaceDay.Api.Data;

public class AppDbContext(DbContextOptions<AppDbContext> options) : DbContext(options)
{
    public DbSet<User> Users => Set<User>();
    public DbSet<Event> Events => Set<Event>();
    public DbSet<Category> Categories => Set<Category>();
    public DbSet<Enrolment> Enrolments => Set<Enrolment>();
    public DbSet<Result> Results => Set<Result>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        b.Entity<User>().HasIndex(u => u.Email).IsUnique();
        b.Entity<Event>().Property(e => e.DistanceKm).HasPrecision(8, 2);

        b.Entity<Event>().HasOne(e => e.Organiser).WithMany().HasForeignKey(e => e.OrganiserId).OnDelete(DeleteBehavior.Restrict);
        b.Entity<Category>().HasOne(c => c.Event).WithMany(e => e.Categories).HasForeignKey(c => c.EventId).OnDelete(DeleteBehavior.Cascade);

        b.Entity<Enrolment>().HasOne(e => e.Event).WithMany(e => e.Enrolments).HasForeignKey(e => e.EventId).OnDelete(DeleteBehavior.Cascade);
        b.Entity<Enrolment>().HasOne(e => e.Category).WithMany().HasForeignKey(e => e.CategoryId).OnDelete(DeleteBehavior.Restrict);
        b.Entity<Enrolment>().HasOne(e => e.User).WithMany().HasForeignKey(e => e.UserId).OnDelete(DeleteBehavior.Restrict);
        b.Entity<Enrolment>().HasIndex(e => new { e.EventId, e.UserId }).IsUnique();

        b.Entity<Result>().HasOne(r => r.Enrolment).WithOne(e => e.Result).HasForeignKey<Result>(r => r.EnrolmentId).OnDelete(DeleteBehavior.Cascade);
    }
}
