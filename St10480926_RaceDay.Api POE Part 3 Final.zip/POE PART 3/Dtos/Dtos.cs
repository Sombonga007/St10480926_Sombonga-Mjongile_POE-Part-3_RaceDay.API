﻿using System.ComponentModel.DataAnnotations;

namespace PROG_RaceDay.Api.Dtos;

// ---------- Input ----------
public class RegisterDto
{
    [Required, StringLength(100)] public string FullName { get; set; } = "";
    [Required, EmailAddress, StringLength(200)] public string Email { get; set; } = "";
    [Required, MinLength(6)] public string Password { get; set; } = "";
    [Required] public string Role { get; set; } = "Participant";
}
public class LoginDto
{
    [Required, EmailAddress] public string Email { get; set; } = "";
    [Required] public string Password { get; set; } = "";
}
public class EventInputDto
{
    [Required, StringLength(150)] public string Name { get; set; } = "";
    [Required, StringLength(2000)] public string Description { get; set; } = "";
    [Required] public DateTime Date { get; set; }
    [Required, StringLength(200)] public string Location { get; set; } = "";
    [Range(0.1, 1000)] public decimal DistanceKm { get; set; }
    [Required, StringLength(50)] public string EventType { get; set; } = "";
}
public class CategoryInputDto
{
    [Required, StringLength(100)] public string Name { get; set; } = "";
    [StringLength(300)] public string? Description { get; set; }
}
public class EnrolDto
{
    [Range(1, int.MaxValue)] public int EventId { get; set; }
    [Range(1, int.MaxValue)] public int CategoryId { get; set; }
}
public class StatusDto { [Required] public string Status { get; set; } = ""; }
public class ResultInputDto
{
    [Range(1, int.MaxValue)] public int EnrolmentId { get; set; }
    [Required] public string FinishTime { get; set; } = ""; // hh:mm:ss
    [Range(1, 100000)] public int Position { get; set; }
}
public class ProfileUpdateDto
{
    [Required, StringLength(100)] public string FullName { get; set; } = "";
    [StringLength(30)] public string? Phone { get; set; }
    public DateTime? DateOfBirth { get; set; }
}

// ---------- Output ----------
public record AuthResponse(string Token, int UserId, string FullName, string Email, string Role, string? ProfilePictureUrl);
public record IdResponse(int Id);
public record UrlResponse(string Url);
public record CategoryDto(int Id, string Name, string? Description);
public record EventSummaryDto(int Id, string Name, string Description, DateTime Date, string Location, decimal DistanceKm, string EventType, string? BannerUrl, string OrganiserName, int EnrolmentCount);
public record EventDetailDto(int Id, string Name, string Description, DateTime Date, string Location, decimal DistanceKm, string EventType, string? BannerUrl, string OrganiserName, int EnrolmentCount, List<CategoryDto> Categories);
public record EnrolmentDto(int Id, int EventId, string EventName, DateTime EventDate, string Location, string? BannerUrl, string CategoryName, string Status, DateTime EnrolledAt);
public record EventEnrolmentDto(int Id, string ParticipantName, string Email, string CategoryName, string Status, DateTime EnrolledAt);
public record ResultRowDto(int EnrolmentId, string ParticipantName, string CategoryName, string? FinishTime, int? Position);
public record MyResultDto(int EventId, string EventName, DateTime EventDate, string CategoryName, string FinishTime, int Position, int TotalFinishers);
public record DashboardEventDto(int Id, string Name, DateTime Date, string Location, int Enrolments, bool IsUpcoming);
public record DashboardDto(int TotalEvents, int TotalEnrolments, int UpcomingEvents, List<DashboardEventDto> Events);
public record ProfileDto(int Id, string FullName, string Email, string Role, string? Phone, DateTime? DateOfBirth, string? ProfilePictureUrl);
