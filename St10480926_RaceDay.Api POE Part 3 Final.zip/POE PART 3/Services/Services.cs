﻿using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Microsoft.IdentityModel.Tokens;
using PROG_RaceDay.Api.Dtos;
using PROG_RaceDay.Api.Models;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace PROG_RaceDay.Api.Services;

public static class Extensions
{
    public static int UserId(this ClaimsPrincipal u) => int.Parse(u.FindFirstValue(ClaimTypes.NameIdentifier)!);
    public static string FormatTime(this TimeSpan t) => $"{(int)t.TotalHours:00}:{t.Minutes:00}:{t.Seconds:00}";
}

public class TokenService(IConfiguration cfg)
{
    public AuthResponse Build(User u)
    {
        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(cfg["Jwt:Key"]!));
        var claims = new[]
        {
            new Claim(ClaimTypes.NameIdentifier, u.Id.ToString()),
            new Claim(ClaimTypes.Name, u.FullName),
            new Claim(ClaimTypes.Email, u.Email),
            new Claim(ClaimTypes.Role, u.Role)
        };
        var token = new JwtSecurityToken(
            cfg["Jwt:Issuer"], cfg["Jwt:Audience"], claims,
            expires: DateTime.UtcNow.AddHours(double.Parse(cfg["Jwt:ExpiryHours"] ?? "8")),
            signingCredentials: new SigningCredentials(key, SecurityAlgorithms.HmacSha256));
        return new AuthResponse(new JwtSecurityTokenHandler().WriteToken(token), u.Id, u.FullName, u.Email, u.Role, u.ProfilePictureUrl);
    }
}

public interface IBlobService
{
    string? Validate(IFormFile file);
    Task<string> UploadAsync(IFormFile file, string folder);
}

public class BlobService(IConfiguration cfg) : IBlobService
{
    private static readonly string[] Allowed = ["image/jpeg", "image/png", "image/webp", "image/gif"];
    private const long MaxBytes = 5 * 1024 * 1024;

    public string? Validate(IFormFile file)
    {
        if (file == null || file.Length == 0) return "Please choose an image to upload.";
        if (file.Length > MaxBytes) return "The image must be smaller than 5 MB.";
        if (!Allowed.Contains(file.ContentType.ToLowerInvariant())) return "Only JPG, PNG, WEBP or GIF images are allowed.";
        return null;
    }

    public async Task<string> UploadAsync(IFormFile file, string folder)
    {
        var container = new BlobContainerClient(cfg["AzureBlob:ConnectionString"], cfg["AzureBlob:Container"]);
        await container.CreateIfNotExistsAsync(PublicAccessType.Blob);
        var blob = container.GetBlobClient($"{folder}/{Guid.NewGuid():N}{Path.GetExtension(file.FileName).ToLowerInvariant()}");
        await using var stream = file.OpenReadStream();
        await blob.UploadAsync(stream, new BlobHttpHeaders { ContentType = file.ContentType });
        return blob.Uri.ToString();
    }
}
